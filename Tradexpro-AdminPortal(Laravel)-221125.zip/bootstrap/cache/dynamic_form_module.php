<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\DynamicForm\\Providers\\DynamicFormServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\DynamicForm\\Providers\\DynamicFormServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);