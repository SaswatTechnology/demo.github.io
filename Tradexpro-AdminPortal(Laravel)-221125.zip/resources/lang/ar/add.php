<?php

return array (
  'to' => 
  array (
    'favorite' => '',
  ),
);
