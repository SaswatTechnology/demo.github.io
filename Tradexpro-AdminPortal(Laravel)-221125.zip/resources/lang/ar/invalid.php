<?php

return array (
  'interval' => '',
);
